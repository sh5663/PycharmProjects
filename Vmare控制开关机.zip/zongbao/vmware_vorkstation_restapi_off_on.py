import requests
import json
import logging
logging.captureWarnings(True)
d={"R1":"IJV87A9VUM793HOG48ODQ7VNGTH5HI91",
   "R2":"H3307K0SADJ20LDS7JF4333N4G54IJJM",
   'R3':"I5LHSACIVTSKENK11AIOP53DU1VKTUS7",
   "R4": "9DAQ70SKGT3UD7OH2DT1EO7540Q3JBK3",
   "R5": "VKP7CUFVLGNPKTB408LEU7PSO23POG6H",
   "R6": "LIAU7JK2A8HC5PPF3KHBTNN4USJNGEVU",
   "R7": "M4G4MQBN0CQ10F6I7KJR0A76SADP9504"
   }
list1=list(d.values())
print(list1)
print("off,on=")
y=input('off/on:')
payload = y
headers = {
    'content-type': 'application/vnd.vmware.vmw.rest-v1+json',
    'Accept': 'application/vnd.vmware.vmw.rest-v1+json',
    'Authorization': 'Basic YWRtaW46QWRtQDEyMzQ='
}
for i in list1:
    url1 = f"https://127.0.0.1:8697/api/vms/{i}/power"
    response = requests.request("PUT", url1, headers=headers, data=payload,verify=False)
    print(response.text)
url2='https://127.0.0.1:8697/api/vms'
response2 = requests.request("GET", url2, headers=headers,verify=False)
print(response2.text)
# cc=response2.text
# dd=eval(cc)
# print (dd)
# print(len(dd))
# print(type(dd))
# print(dd[0]['path'],dd[0]['id'])