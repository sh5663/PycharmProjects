import os
print('1:on_system','2:off_system')
x=input("name:")
print(x)
# print(type(x))
if x=="1":
     connet = ''' d: &\
                  cd D:\Program Files (x86)\VMware\VMware Workstation\ &\
                  vmrest -c workstationapi-cert.pem -k workstationapi-key.pem
               '''
     d=os.system(connet)
     print(d)
elif x=="2":
     off=os.system('taskkill /f /t /im vmrest.exe')
     print(off)
else:
     print('input error')
